import React from 'react'

const auth = () => {
  return (
    <div>auth</div>
  )
}

export default auth